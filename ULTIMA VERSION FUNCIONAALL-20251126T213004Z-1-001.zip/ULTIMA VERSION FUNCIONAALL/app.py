import streamlit as st
import sys
import os
import pandas as pd
import glob
from time import sleep
from datetime import datetime

# --- CONFIGURACIÓN ---
CARPETA_DISCO = "/home/pi/disco_iot"

# --- FUNCIÓN DE LECTURA ---
def obtener_datos_completos():
    datos = {
        "esp32": None, "arduino": None, 
        "tabla_visual": pd.DataFrame(), "tabla_exportar": pd.DataFrame()
    }
    try:
        patron = f"{CARPETA_DISCO}/datos_aerogenerador_*.csv"
        lista_archivos = glob.glob(patron)
        if not lista_archivos: return datos
            
        archivo_mas_nuevo = max(lista_archivos, key=os.path.getctime)
        
        if os.path.exists(archivo_mas_nuevo):
            df = pd.read_csv(archivo_mas_nuevo, on_bad_lines='skip')
            if not df.empty:
                df.columns = df.columns.str.strip().str.lower()
                renombres = {
                    'potencia (w)': 'potencia', 'corriente (a)': 'corriente',
                    'tiempo': 'TIEMPO', 'movimientos': 'movimiento', 'rpms': 'rpm'
                }
                df.rename(columns=renombres, inplace=True)

                col_tiempo = 'TIEMPO' if 'TIEMPO' in df.columns else 'tiempo'
                if col_tiempo in df.columns:
                    df = df[df[col_tiempo].astype(str).str.lower() != 'tiempo']
                    df = df.sort_values(by=col_tiempo, ascending=False)
                
                datos["tabla_visual"] = df.head(10)
                datos["tabla_exportar"] = df
                
                if not df.empty:
                    ultimo = df.iloc[0]
                    def get_safe(col): return ultimo[col] if col in df.columns else 0
                    datos["esp32"] = {
                        'rpm': get_safe('rpm'), 'movimiento': get_safe('movimiento'),
                        'potencia': get_safe('potencia'), 'corriente': get_safe('corriente')
                    }

        fecha = archivo_mas_nuevo.split('_')[-1].replace('.csv', '')
        archivo_ard = f"{CARPETA_DISCO}/datos_arduino_{fecha}.csv"
        if os.path.exists(archivo_ard):
            df_ard = pd.read_csv(archivo_ard, on_bad_lines='skip')
            if not df_ard.empty:
                df_ard.columns = df_ard.columns.str.strip().str.lower()
                col_t = 'TIEMPO' if 'TIEMPO' in df_ard.columns else 'tiempo'
                if col_t in df_ard.columns:
                    df_ard = df_ard[df_ard[col_t].astype(str).str.lower() != 'tiempo']
                    df_ard = df_ard.sort_values(by=col_t, ascending=False)
                if not df_ard.empty:
                    val = 0
                    if 'valor' in df_ard.columns: val = df_ard.iloc[0]['valor']
                    elif 'value' in df_ard.columns: val = df_ard.iloc[0]['value']
                    datos["arduino"] = val
        return datos
    except: return datos

# --- INTERFAZ ---
st.set_page_config(layout="wide", page_title="Monitor Aerogenerador", page_icon="⚡")

class App:
    def __init__(self): self.page = st
        
    def show_iot_dashboard(self):
        col_tit, col_check = self.page.columns([4, 1])
        col_tit.markdown("# ⚡ Sistema de Monitoreo de Aerogenerador")
        auto_refresh = col_check.toggle("🔄 Auto-Actualizar (2s)", value=True)
        
        info = obtener_datos_completos()
        datos_esp = info["esp32"]
        val_arduino = info["arduino"]
        df_visual = info["tabla_visual"]
        df_completo = info["tabla_exportar"]
        
        rpm_val = 0
        mov_texto = "Sin Datos"
        ard_val = "Sin Datos"
        potencia = 0; corriente = 0
        
        if val_arduino is not None: ard_val = val_arduino
        if datos_esp is not None:
            rpm_val = datos_esp.get('rpm', 0)
            potencia = datos_esp.get('potencia', 0)
            corriente = datos_esp.get('corriente', 0)
            try:
                mov_num = int(float(datos_esp.get('movimiento', 0)))
                mov_texto = "Detectado 🚨" if mov_num == 1 else "Inactivo"
            except: mov_texto = "Error"

        self.page.write(f"Última actualización: {datetime.now().strftime('%H:%M:%S')}")
        self.page.markdown("---")

        kpi1, kpi2, kpi3, kpi4 = self.page.columns(4)
        kpi1.metric("RPM (Velocidad)", f"{rpm_val}")
        kpi2.metric("Movimiento", mov_texto)
        kpi3.metric("Potencia", f"{potencia} W")
        kpi4.metric("Corriente", f"{corriente} A")
        
        c1, c2 = self.page.columns(2)
        c1.metric("Sensor Arduino", ard_val)
        
        self.page.markdown("---")
        self.page.subheader(f"📋 Registros del Día")
        self.page.dataframe(df_visual, use_container_width=True)
        
        if not df_completo.empty:
            csv_data = df_completo.to_csv(index=False).encode('utf-8')
            self.page.download_button(label=f"📥 Descargar Historial ({len(df_completo)})",
                data=csv_data, file_name=f"registros_{datetime.now().strftime('%Y-%m-%d')}.csv",
                mime='text/csv', key='descargar_csv_iot')
        else: self.page.info("ℹ️ Esperando datos...")
        
        self.page.markdown("---")
        self.page.subheader("💿 Gestión de Disco Duro")
        col_d1, col_d2 = self.page.columns([3, 1])
        col_d1.warning("⚠️ Siempre EXPULSA el disco antes de desconectar.")
        
        if col_d2.button("⏏️ EXPULSAR DISCO SEGURO", type="primary", key="btn_expulsar"):
            with st.spinner("🛑 Guardando y desmontando..."):
                try:
                    os.chdir("/home/pi")
                    os.system("sudo pkill -f guardian.py")
                    sleep(2)
                    os.system("sudo fuser -k -9 /home/pi/disco_iot")
                    sleep(2)
                    ret = os.system("sudo umount /home/pi/disco_iot")
                    if ret == 0:
                        self.page.success("✅ LISTO. Puedes llevarte el disco.")
                        self.page.balloons()
                    else: self.page.error("⚠️ Error al desmontar.")
                except Exception as e: self.page.error(f"Error: {e}")

        self.page.markdown("---")
        if self.page.button("🔄 Reiniciar Sistema (Al reconectar disco)"):
            self.page.warning("Reiniciando... Espera 2 minutos.")
            sleep(1)
            os.system("sudo reboot")

        if auto_refresh: sleep(2); st.rerun()

    def run(self): self.show_iot_dashboard()

app = App()
app.run()
