import time
import os
import csv
import json
import serial
import paho.mqtt.client as mqtt
from datetime import datetime

# --- CONFIGURACIÓN ---
PUERTO_ARDUINO = '/dev/ttyACM0'
BAUD_RATE = 9600
BROKER = "localhost"
TOPIC_ESP32 = "casa/esp32/sensor"
CARPETA_DISCO = "/home/pi/disco_iot" 
TIEMPO_TOLERANCIA = 10 

# Variables globales
ultimo_movimiento_timestamp = 0

# --- FUNCIÓN CSV ESP32 ---
def guardar_csv_esp32(datos_dict):
    try:
        fecha_hoy = datetime.now().strftime("%Y-%m-%d")
        archivo = f"{CARPETA_DISCO}/datos_aerogenerador_{fecha_hoy}.csv"
        es_nuevo = not os.path.exists(archivo)
        
        with open(archivo, mode='a', newline='') as f:
            campos = ['TIEMPO', 'Potencia (W)', 'Corriente (A)', 'movimiento', 'rpm']
            writer = csv.DictWriter(f, fieldnames=campos)
            if es_nuevo: writer.writeheader()
            writer.writerow(datos_dict)
            print(f"✅ CSV: {datos_dict['rpm']} RPM | Mov: {datos_dict['movimiento']}")
    except Exception as e:
        print(f"❌ Error CSV: {e}")

# --- FUNCIÓN CSV ARDUINO ---
def guardar_csv_arduino(dato):
    try:
        fecha_hoy = datetime.now().strftime("%Y-%m-%d")
        archivo = f"{CARPETA_DISCO}/datos_arduino_{fecha_hoy}.csv"
        es_nuevo = not os.path.exists(archivo)
        
        with open(archivo, mode='a', newline='') as f:
            campos = ['TIEMPO', 'Valor']
            writer = csv.DictWriter(f, fieldnames=campos)
            if es_nuevo: writer.writeheader()
            writer.writerow({'TIEMPO': datetime.now().strftime("%Y-%m-%d %H:%M:%S"), 'Valor': dato})
    except Exception as e:
        print(f"❌ Error Arduino: {e}")

# --- MQTT ---
def on_connect(client, userdata, flags, rc):
    print(f"📡 MQTT Conectado ({rc})")
    client.subscribe(TOPIC_ESP32)

def on_message(client, userdata, msg):
    global ultimo_movimiento_timestamp
    try:
        payload = msg.payload.decode()
        json_data = json.loads(payload)
        
        rpms = json_data.get('rpms', [0])
        movs = json_data.get('movimientos', [0])
        pots = json_data.get('potencias', [0])
        corrs = json_data.get('corrientes', [0])
        
        rpm_val = rpms[0] if rpms else 0
        mov_val = movs[0] if movs else 0
        pot_val = pots[0] if pots else 0
        corr_val = corrs[0] if corrs else 0
        
        # FILTRO DE TIEMPO
        guardar = False
        ahora = time.time()
        
        if rpm_val > 0:
            guardar = True
            ultimo_movimiento_timestamp = ahora
        elif (ahora - ultimo_movimiento_timestamp) < TIEMPO_TOLERANCIA:
            guardar = True
        
        if guardar:
            fila = {
                'TIEMPO': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                'Potencia (W)': pot_val,
                'Corriente (A)': corr_val,
                'movimiento': mov_val,
                'rpm': rpm_val
            }
            guardar_csv_esp32(fila)

    except Exception as e:
        print(f"Error: {e}")

# --- ARDUINO ---
def leer_arduino_loop():
    while True:
        try:
            ser = serial.Serial(PUERTO_ARDUINO, BAUD_RATE, timeout=1)
            print("🔌 Arduino Conectado")
            while True:
                if ser.in_waiting > 0:
                    try:
                        linea = ser.readline().decode('utf-8').strip()
                        if linea: guardar_csv_arduino(linea)
                    except: pass
                time.sleep(0.1)
        except:
            time.sleep(2)

if __name__ == "__main__":
    print("🚀 Iniciando Guardián CSV...")
    # Esperar montaje real del disco
    while not os.path.ismount(CARPETA_DISCO):
        print(f"⏳ Esperando disco en {CARPETA_DISCO}...")
        time.sleep(5)
    
    client = mqtt.Client()
    client.on_connect = on_connect
    client.on_message = on_message
    
    try:
        client.connect(BROKER, 1883, 60)
        client.loop_start()
    except: pass

    leer_arduino_loop()
