#!/bin/bash

# 1. Esperar red y sistema (20 seg)
sleep 20

# --- MONTAR DISCO DURO (Por si acaso no se montó al inicio) ---
sudo mount -a
sleep 5
# -----------------------------------------------------------

# 2. Iniciar GUARDIAN (Lectura de sensores)
screen -dmS guardian bash -c 'cd /home/pi; source env/bin/activate; python guardian.py; exec bash'

# 3. Esperar un poco
sleep 5

# 4. Iniciar APP (Visualización)
screen -dmS main_app bash -c 'cd /home/pi/sistema/Proyecto-Aerogenerador-CA-main; source /home/pi/env/bin/activate; streamlit run app/app.py --server.port 8501 --server.address 0.0.0.0 --server.enableCORS false --server.enableXsrfProtection false; exec bash'

# 5. Iniciar NGROK (Acceso Remoto)
screen -dmS tunel_ngrok ngrok http 8501
